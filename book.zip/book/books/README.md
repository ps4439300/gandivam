"# gandivam" 
